/**
 * 
 */
package arcade.menu;

import java.util.ArrayList;
import java.util.Comparator;
import arcade.exceptions.Checkers;

/**
 * @author jesus
 *
 */
public class Players {
	/**
	 * players : list of the players
	 */
	private ArrayList<Player> players;
	
	public Players() {
		this.players = new ArrayList<Player>();
	}
	public ArrayList<Player> getPlayers() {
		return this.players;
	}

	/**
	 * @param newPlayer : The player that is going to be added
	 * @return Adds a new player to the List, sort the list by the players' score and set the winner
	 */
	public void addPlayer(Player newPlayer) {
		Checkers.checkNoNull(newPlayer);
		players.add(newPlayer);

		players.sort(Comparator.comparingInt(Player::getScore).reversed());
		players = setTheWinner(players);
	}
	
	/**
	 * @param data : Aux param
	 * @return Change the status of isWinner = TRUE of the player with the highest score
	 */
	private ArrayList<Player> setTheWinner(ArrayList<Player> data) {

		data.forEach(p->p.setWinner(Boolean.FALSE));
		data.get(0).setWinner(Boolean.TRUE);
		return data;
		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "" + players + "";
	}
	
}
