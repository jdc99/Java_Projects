/**
 * 
 */
package arcade.menu;

import arcade.exceptions.Checkers;

/**
 * @author jesus
 *
 */
public class Player {

	/**
	 *		name : the name of the player
	 */
	private String name;
	/**
	 * 		score : the score associated with this player, starts with zero
	 * 					 and begins to increase through playing
	 */
	private Integer score;
	/**
	 * 		isWinner : evaluating the score of the rest of players it decides who has the biggest score
	 */
	private Boolean isWinner;
	
	public Player(String name) {
		this.name = name;
		this.score = 0;
		this.isWinner = Boolean.FALSE;
	}

	/**
	 * @return The name of the player
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name The name to set
	 */
	public void setName(String name) {
		Checkers.checkNoNull(name);
		this.name = name;
	}

	/**
	 * @return The score of the player
	 */
	public Integer getScore() {
		return score;
	}
	
	/**
	 * @param score The score to set
	 */
	public void setScore(Integer score) {
		Checkers.checkNoNull(score);
		Checkers.check("THE NEW SCORE CAN'T BE NEGATIVE", score>=0);
		this.score = score;
	}

	/**
	 * @return If the player is the winner or not
	 */
	public Boolean getIsWinner() {
		return isWinner;
	}

	/**
	 * @param isWinner Changes the player's status
	 */
	public void setWinner(Boolean isWinner) {
		Checkers.checkNoNull(isWinner);
		this.isWinner = isWinner;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + score;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Player other = (Player) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (score != other.score)
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Name : " + name + "																										Score : " + score + "	Winner? : " + isWinner  + "";
	}
	
	public int compareTo(Player p) {
		int result = this.getName().compareToIgnoreCase(p.getName());
		if (result == 0) {
			result = this.getScore().compareTo(p.getScore());
			if (result == 0) {
				result = this.getIsWinner().compareTo(p.getIsWinner());
			}
		}
		return result;
	}
	
	
}
