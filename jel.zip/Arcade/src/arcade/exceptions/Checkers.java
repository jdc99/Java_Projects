/**
 * 
 */
package arcade.exceptions;

/**
 * @author jesus
 *
 */
public class Checkers {

	/**
	 * @param exceptionText Text that will be shown in case an exception is thrown
	 * @param condition Condition that is checked
	 */
	public static void check(String exceptionText, Boolean condition) {
		if(condition.equals(Boolean.FALSE.booleanValue())) {
			throw new IllegalArgumentException(exceptionText);
		}
	}

	/**
	 * @param objects Group of objects that can not be null
	 */
	public static void checkNoNull(Object...objects) {
		try {
			for(Object o:objects) {
				if(o.equals(null)) {}
			}
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
